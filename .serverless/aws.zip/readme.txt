sudo npm install -g serverless

se crea la cuenta serverless y se asocia con las respectivas KEY de aws
por default se crea una funcion lambda la cual se verifica q es creada en la cuenta aws asociada.

serverless login
serverles dashboard
serverless deploy ---esto crea la lambda en aws

handler.js es la lambda o el handler de la lambda

npm i aws-serverless-express

npm i express body-parser cors

npm i aws-serverless-express


https://www.youtube.com/watch?v=lm7fn72eA8c



